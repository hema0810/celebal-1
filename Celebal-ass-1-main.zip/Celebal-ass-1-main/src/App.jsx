import React from 'react'
import RegistrationApp from './components/RegistrationApp'

const App = () => {
  return (
    <div style={{backgroundColor:"#f7ede2"}}>
      <RegistrationApp />
    </div>
  )
}

export default App